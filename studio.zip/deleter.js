var url = window.location.pathname.split("/");
setTimeout(() => { 
if(url[url.length-2] === "projects") {
	var element = document.getElementById("project-action-bar");
	var button = document.createElement('div');
	button.classList.add('button');
	button.classList.add('grey');
	button.classList.add('small');
	button.textContent = " Delete all projects ";
	button.addEventListener("click", function(){ for(var i = 0;i<document.getElementsByClassName("remove").length;i++) {
			document.getElementsByClassName("remove")[i].click();
	} }); 
	element.appendChild(button);
}
if(url[url.length-2] === "curators") {
	var element = document.getElementById("curator-action-bar");
	var button = document.createElement('div');
	button.classList.add('button');
	button.classList.add('grey');
	button.classList.add('small');
	button.textContent = " Add all followers ";
        document.getElementById("open").click();
	button.addEventListener("click", function(){ 
	if(document.getElementById("explore-header-closed").getAttribute("data-control") === "open") {document.getElementById("open").click();}
	for(var i = 0;i<document.getElementsByClassName("add-label").length;i++) {
			document.getElementsByClassName("add-label")[i].click();
	} }); 
	element.appendChild(button);
}  }, 500);